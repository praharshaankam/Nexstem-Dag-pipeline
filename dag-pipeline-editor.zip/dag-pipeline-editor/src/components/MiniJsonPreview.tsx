import React from 'react'
import { Edge, Node } from 'reactflow'

type Props = {
  nodes: Node[]
  edges: Edge[]
}

export default function MiniJsonPreview({ nodes, edges }: Props) {
  return (
    <div className="text-xs bg-white p-2 rounded shadow mt-2 max-h-48 overflow-auto">
      <pre>{JSON.stringify({ nodes, edges }, null, 2)}</pre>
    </div>
  )
}
