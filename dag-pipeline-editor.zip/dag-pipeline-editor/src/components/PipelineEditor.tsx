import React, { useCallback, useState } from 'react'
import ReactFlow, {
  addEdge,
  Background,
  Controls,
  Connection,
  Edge,
  MiniMap,
  Node,
  ReactFlowProvider,
  useEdgesState,
  useNodesState,
  MarkerType,
  Panel,
} from 'reactflow'
import 'reactflow/dist/style.css'
import dagre from 'dagre'
import MiniJsonPreview from './MiniJsonPreview'
import useDagValidation from '../hooks/useDagValidation'

let id = 0
const getId = () => `node_${id++}`

const nodeWidth = 150
const nodeHeight = 50

export default function PipelineEditor() {
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])

  const onConnect = useCallback((connection: Connection) => {
  if (!connection.source || !connection.target) return
  if (connection.source === connection.target) return

  setEdges((eds) =>
    addEdge(
      {
        ...connection,
        markerEnd: { type: MarkerType.ArrowClosed },
      },
      eds
    )
  )
}, [setEdges])


  const addNode = () => {
  const label = prompt("Enter node label:")
  if (!label) return

  const newNode: Node = {
    id: getId(),
    data: { label },
    position: { x: Math.random() * 250, y: Math.random() * 250 },
    sourcePosition: 'right', 
    targetPosition: 'left',  
  }

  setNodes((nds) => [...nds, newNode])
}


  const onDelete = useCallback(() => {
    setNodes((nds) => nds.filter((n) => !n.selected))
    setEdges((eds) => eds.filter((e) => !e.selected))
  }, [setNodes, setEdges])

  const autoLayout = () => {
    const g = new dagre.graphlib.Graph()
    g.setDefaultEdgeLabel(() => ({}))
    g.setGraph({ rankdir: "LR" })

    nodes.forEach((node) => {
      g.setNode(node.id, { width: nodeWidth, height: nodeHeight })
    })

    edges.forEach((edge) => {
      g.setEdge(edge.source, edge.target)
    })

    dagre.layout(g)

    const newNodes = nodes.map((node) => {
      const pos = g.node(node.id)
      return {
        ...node,
        position: { x: pos.x - nodeWidth / 2, y: pos.y - nodeHeight / 2 },
      }
    })

    setNodes([...newNodes])
  }

  const { isValid, message } = useDagValidation(nodes, edges)

  return (
    <ReactFlowProvider>
      <div className="h-full w-full relative">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          fitView
          deleteKeyCode={["Backspace", "Delete"]}
        >
          <MiniMap />
          <Controls />
          <Background />
          <Panel position="top-left">
            <div className="space-x-2 p-2">
              <button onClick={addNode} className="bg-blue-500 text-white px-2 py-1 rounded">Add Node</button>
              <button onClick={autoLayout} className="bg-green-500 text-white px-2 py-1 rounded">Auto Layout</button>
              <button onClick={onDelete} className="bg-red-500 text-white px-2 py-1 rounded">Delete</button>
            </div>
          </Panel>
          <Panel position="bottom-left">
            <div className="p-2 text-sm font-medium">
              Status: <span className={isValid ? "text-green-600" : "text-red-600"}>{message}</span>
            </div>
          </Panel>
        </ReactFlow>
        <MiniJsonPreview nodes={nodes} edges={edges} />
      </div>
    </ReactFlowProvider>
  )
}
