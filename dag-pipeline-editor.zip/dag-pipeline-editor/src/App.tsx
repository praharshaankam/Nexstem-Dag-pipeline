import React from 'react'
import PipelineEditor from './components/PipelineEditor'

export default function App() {
  return (
    <div className="h-screen w-full p-4">
      <PipelineEditor />
    </div>
  )
}
