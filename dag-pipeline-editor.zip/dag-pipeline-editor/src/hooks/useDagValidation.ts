import { Edge, Node } from 'reactflow'
import { useMemo } from 'react'

function detectCycle(nodes: Node[], edges: Edge[]): boolean {
  const adj: Record<string, string[]> = {}
  nodes.forEach((node) => {
    adj[node.id] = []
  })
  edges.forEach((edge) => {
    if (edge.source !== edge.target) {
      adj[edge.source].push(edge.target)
    }
  })

  const visited: Record<string, boolean> = {}
  const recStack: Record<string, boolean> = {}

  const dfs = (node: string): boolean => {
    if (!visited[node]) {
      visited[node] = true
      recStack[node] = true
      for (const neighbor of adj[node]) {
        if (!visited[neighbor] && dfs(neighbor)) return true
        else if (recStack[neighbor]) return true
      }
    }
    recStack[node] = false
    return false
  }

  return nodes.some((n) => dfs(n.id))
}

export default function useDagValidation(nodes: Node[], edges: Edge[]) {
  return useMemo(() => {
    if (nodes.length < 2) return { isValid: false, message: "Add at least 2 nodes" }

    const hasSelfLoops = edges.some((e) => e.source === e.target)
    if (hasSelfLoops) return { isValid: false, message: "Self-loops are not allowed" }

    const invalidDirs = edges.some((e) => {
  const src = nodes.find((n) => n.id === e.source)
  const tgt = nodes.find((n) => n.id === e.target)
  if (!src || !tgt) return true           // edge references missing node
  return src.sourcePosition !== 'right'   // bad source side
      || tgt.targetPosition !== 'left'    // bad target side
})
    if (invalidDirs) return { isValid: false, message: "Invalid edge direction" }

    const allConnected = nodes.every((n) =>
      edges.some((e) => e.source === n.id || e.target === n.id)
    )
    if (!allConnected) return { isValid: false, message: "All nodes must be connected" }

    if (detectCycle(nodes, edges)) return { isValid: false, message: "Cycle detected" }

    return { isValid: true, message: "Valid DAG" }
  }, [nodes, edges])
}
