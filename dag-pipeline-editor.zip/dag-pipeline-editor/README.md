# Pipeline Editor (DAG Builder)

A react app deploying pipeline-editor (Dag-builder) .

## Features

- Add nodes
- Draw directed edges
- Validate DAG in real-time
- Auto-layout using Dagre
- Delete nodes or edges with Delete/Backspace
- Mini JSON DAG preview

## Setup Instructions

npm install
npm run dev

Visit `http://localhost:5173` to interact with the editor.

## Libraries Used

ReactFlow
Dagre
TailwindCSS (CDN)

## Notes

Nodes must connect from output (right) to input (left).
Invalid connections and cycles are disallowed.
Use Auto Layout for clean arrangement.

## Output
