# Pipeline Editor (DAG Builder)

A visual DAG editor built with React, TypeScript, and ReactFlow.

## Features
- Add nodes
- Draw directed edges
- Validate DAG in real-time
- Auto-layout using Dagre
- Delete nodes or edges with Delete/Backspace
- Mini JSON DAG preview

## Setup Instructions

```bash
npm install
npm run dev
```

Visit `http://localhost:5173` to interact with the editor.

## Libraries Used
- [ReactFlow](https://reactflow.dev/)
- [Dagre](https://github.com/dagrejs/dagre)
- TailwindCSS (CDN)

## Notes
- Nodes must connect from output (right) to input (left).
- Invalid connections and cycles are disallowed.
- Use Auto Layout for clean arrangement.

## Demo
Add screen recordings and screenshots here.

---
Created for frontend intern assignment.
